#include <stdio.h>

int main(){

    int pedagio;
    float gasolina=2.6, km, totalGasto;

    printf("Qual a distancia percorrida?\n");
    scanf("%f", & km);

    printf("Quantos pedagios foram passados?\n");
    scanf("%d", & pedagio);

    totalGasto = (km/15)*gasolina+(8*pedagio);

    printf("Com %.0f km rodados e com %d pedagios passados o custo da viagem eh: R$%.2f", km, pedagio,totalGasto);

    return 0;
}
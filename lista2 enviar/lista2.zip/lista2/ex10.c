#include <stdio.h>

int main(){

    float raio, volume;

    printf("Digite a medida do raio da esfera:\n");
    scanf("%f", & raio);

    volume = (4.0/3.0)*3.14159*(raio*raio*raio);

    printf("O volume da esfera eh: %.3f", volume);

    return 0;
}
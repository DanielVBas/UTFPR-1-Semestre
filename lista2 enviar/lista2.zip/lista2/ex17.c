#include <stdio.h>

int main(){

    int celsius;
    float farenheit;

    printf("Qual a temperatura em celsius?");
    scanf("%d", & celsius);

    farenheit = celsius*1.8 +32;

    printf("%d graus celsius é %.2f Farenheit", celsius,farenheit);

    return 0;
}
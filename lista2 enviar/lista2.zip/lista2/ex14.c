#include <stdio.h>

int main(){

    int total;


    printf("Qual o valor?");
    scanf("%d", & total);

    printf("R$%d = %d cedulas de R$50, %d cedulas de R$5 e %d cedulas de R$1.",total, total/50, total%50/5,total%50%5);


    return 0;
}
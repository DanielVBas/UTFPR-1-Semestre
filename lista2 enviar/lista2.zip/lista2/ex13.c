#include <stdio.h>

int main(){

    int km;
    float litrosGastos;

    printf("Qual a kilometragem rodada?");
    scanf("%d", & km);

    printf("Quantos litros de combustivel foram gastos?");
    scanf("%f", & litrosGastos);

    printf("Consumo medio do automovel: %.3f km/l", km/litrosGastos);



    return 0;
}
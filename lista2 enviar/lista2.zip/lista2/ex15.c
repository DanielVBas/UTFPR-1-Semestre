#include <stdio.h>

int main(){

    int segundos, dias, horas, minutos, segundosResto;


    printf("Qual a quantidade de segundos?");
    scanf("%d", & segundos);

    dias = segundos/86400;
    horas = segundos%86400/3600;
    minutos = segundos%86400%3600/60;
    segundosResto = segundos%86400%3600%60;

    printf("%d segundos correspondem a %d dias, %d horas, %d minutos e %d segundos.",segundos, dias, horas, minutos, segundosResto);

    return 0;
}

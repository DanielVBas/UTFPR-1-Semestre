#include <stdio.h>

int main(){

    char caracter;
    int numeroInteiro;
    float numeroReal;

    printf("Digite apenas um caracter:\n");
    scanf("%c", & caracter);

    printf("Digite um numero inteiro:\n");
    scanf("%d", & numeroInteiro);

    printf("Digite um numero real:\n");
    scanf("%f", & numeroReal);

    printf("O Caracter digitado foi: %c\n", caracter);
    printf("O numero inteiro digitadoi foi: %d\n", numeroInteiro);
    printf("O numero real digitado foi: %f\n", numeroReal);


    return 0;
}
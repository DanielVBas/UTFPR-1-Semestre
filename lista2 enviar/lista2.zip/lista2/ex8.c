#include <stdio.h>
int main () {
    char aux ;

    printf (" Digite um caracter : ");
    scanf ("%c", & aux );
    printf ("%c", aux );

    return 0;

// É o numero que representa o caracter no ASCII, o significado dele é que esse numero representa as a codição que vai ser transformado para binarios.
}
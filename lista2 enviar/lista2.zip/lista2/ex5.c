#include <stdio.h>

int main(){

    int i1,i2, divis, rest;

    printf("Digite o numerador: ");
    scanf("%d", & i1);

    printf("Digite o denominador: ");
    scanf("%d", & i2);

    divis = i1/i2;
    rest = i1%i2;

    printf("A divisao de %d por %d deu %d\n", i1,i2, divis);
    printf("O resto da divisao de %d por %d deu %d", i1,i2, rest);

// A diferença é que se a variavel divis for declarada como inteira ela arredonda o a resposta para um numero inteiro.
    return 0;
}
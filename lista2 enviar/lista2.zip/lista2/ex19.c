#include <stdio.h>

int main(){

    float n1,n2,n3, media;

    printf("Qual a primeira nota?\n");
    scanf("%f", & n1);

    printf("Qual a segunda nota ?\n");
    scanf("%f", & n2);

    printf("Qual a terceira nota ?\n");
    scanf("%f", & n3);

    media = ((n1*2)+(n2*3)+(n3*5))/(2+3+5);

    printf("A media é %.2f", media);

    return 0;
}
#include <stdio.h>

int main(){

    int numeroInteiro;
    char caracter;
    float numeroReal;

    printf("Digite um numero inteiro:\n");
    scanf("%d", & numeroInteiro);

    printf("Digite apenas um caracter:\n");
    scanf(" %c", & caracter);

    printf("Digite um numero real:\n");
    scanf("%f", & numeroReal);

   
    printf("O numero inteiro digitadoi foi: %d\n", numeroInteiro);
    printf("O Caracter digitado foi: %c\n", caracter);
    printf("O numero real digitado foi: %f\n", numeroReal);


    return 0;
}
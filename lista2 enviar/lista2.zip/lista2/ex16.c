#include <stdio.h>

int main(){

    int numero,conta ;

    printf("Digite um numero inteiro");
    scanf("%d", & numero);

    conta = numero % 10;

    printf("Ultimo digito: %d", conta);



}

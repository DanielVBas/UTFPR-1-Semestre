#include <stdio.h>

int main(){

    int n1,n2;
    float media;

    printf("Digite o primeiro valor para calcular a media: ");
    scanf("%d", & n1);

    printf("Digite o segundo valor para calcular a media: ");
    scanf("%d", & n2);

    media = (n1 + n2)/2.0;


    printf("A media de %d e %d eh %.2f\n", n1,n2, media);
    return 0;
}
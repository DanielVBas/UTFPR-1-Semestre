#include <stdio.h>

int main () {
    int aux ;

    printf (" Digite um numero inteiro : ");
    scanf ("%d", & aux );
    printf ("%d", aux );
    return 0;

//Ocorreu um erro de execução, a correção necessaria foi mudar o %f do printf para %d, pois a entrada era um int e não um float.
}
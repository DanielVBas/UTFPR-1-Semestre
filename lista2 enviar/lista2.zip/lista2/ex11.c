#include <stdlib.h>
#include <stdio.h>

int main(){

    int a,b,maxAB;

    printf("Digite um valor inteiro:");
    scanf("%d", & a);

    printf("Digite um valor inteiro:");
    scanf("%d", & b);

    maxAB = (a+b+ abs(a-b))/2;

    printf("O maximo de a e b eh:%d", maxAB);

    return 0;
}
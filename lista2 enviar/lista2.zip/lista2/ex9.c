#include <stdio.h>

int main(){

    float base, altura, perimetro;

    printf("Digite a medida da base do retangulo:\n");
    scanf("%f", & base);

    printf("Digite a medida da altura do retangulo:\n");
    scanf("%f", & altura);

    perimetro = base*2 + altura*2;

    printf("O perimetro do retangulo eh: %.2f", perimetro);





    return 0;
}
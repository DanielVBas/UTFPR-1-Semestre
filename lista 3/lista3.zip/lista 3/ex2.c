#include <stdio.h>

int main(){

    float altura, base, perimetro, area;
    printf("Qual a base do retangulo?");
    scanf("%f", &base);

    printf("Qual a altura do retangulo?");
    scanf("%f", &altura);

    perimetro = 2*base+2*altura;

    area = base* altura;

    if(perimetro >area){

        printf("O perimetro é maior que a area");
    }
    else{

        printf("O perimetro nao é maior que a area");
    }

    return 0;
}

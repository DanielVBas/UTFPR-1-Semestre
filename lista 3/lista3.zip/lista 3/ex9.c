#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(){

    int n1,n2,operacao,resultado,resultadoreal;
    clock_t tempo;
    srand(time(NULL));
    n1= rand()%100;
    n2= rand()%100;

    operacao = rand()%10;

    if(operacao == 0){
        operacao = rand()%10;

    }
    else if (operacao > 5){
        operacao = operacao -5;
    }
    tempo = clock();
    if(operacao == 1){
        printf("Quanto eh %d + %d ?",n1,n2);
        scanf("%d",&resultado);
        resultadoreal = n1+n2;

    }
    else if(operacao == 2){
        printf("Quanto eh %d - %d ?",n1,n2);
        scanf("%d",&resultado);
        resultadoreal = n1-n2;
    }
    else if(operacao == 3){
        printf("Quanto eh %d * %d ?",n1,n2);
        scanf("%d",&resultado);
        resultadoreal = n1*n2;
    }
    else if(operacao == 4){
        printf("Quanto eh %d/%d ?",n1,n2);
        scanf("%d",&resultado);
        resultadoreal = n1/n2;
    }
    else if(operacao == 5){
        printf("Quanto eh o resto da divisao de %d por %d ?",n1,n2);
        scanf("%d",&resultado);
        resultadoreal = n1%n2;
    }
    tempo = clock() - tempo;
    double tempo_total = ((double)tempo)/CLOCKS_PER_SEC;

    if(resultado==resultadoreal){


        printf("Parabens, voce acertou, o seu tempo foi de: %.f segundos",tempo_total);

    }
    else{

        printf("Voce errou e levou %.f segundos. ;(", tempo_total);
    }


    return 0;
}
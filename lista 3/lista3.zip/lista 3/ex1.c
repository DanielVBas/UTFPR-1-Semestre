#include <stdio.h>

int main(){

    int alunos,monitores;

    printf("Qual o numero de alunos que subiram no bondinho?\n");
    scanf("%d", &alunos);

    printf("Qual o numero de monitores que subiram no bondinho?\n");
    scanf("%d", &monitores);

    if(monitores + alunos <= 50){

        printf("Eh possivel levar todos");


    }
    else{
    printf("Nao eh possivel levar todos");

    }


return 0;
}

#include <stdio.h>
#include <math.h>

int main(){

    float a,b,c,delta,raz1,raz2;

    printf("Digite a, b e c:\n");
    scanf("%f %f %f", &a,&b,&c);

    delta = b*b-4*a*c;

    raz1=(-b+sqrt(delta))/2*a;
    raz2=(-b-sqrt(delta))/2*a;

    if(delta>=0){

        printf("As raizes reais são: Raiz 1 = %f, Raiz 2 = %f", raz1, raz2);
    }
    else if(delta < 0){

        printf("As raizes sao imaginarias");
    }
    if(raz1 == raz2){

        printf("As raizes são iguais");

    }
}


#include <stdio.h>

int main(){

    int dia,mes,ano;
    int k,j,h;

    printf("Digite o dia, mes e ano de nascimento no estilo 01/03/2013:\n");
    scanf("%d/%d/%d", &dia, &mes, &ano);

    if(mes<=2){
        mes=mes+12;
        ano=ano-1;
    }
    
    j=ano/100;
    k= ano%100;

    h =dia+((mes+1)*26/10)+k+(k/4)+((ano/100)/4)+ 5*(ano/100);

    h= h % 7;


    if(h==0){
        printf("O dia da semana nessa data eh sabado");
    }
    else if(h==1){
        printf("O dia da semana nessa data eh domingo");
    }
    else if(h==2){
        printf("O dia da semana nessa data eh segunda");
    }
    else if(h==3){
        printf("O dia da semana nessa data eh terça");
    }
    else if(h==4){
        printf("O dia da semana nessa data eh quarta");
    }
    else if(h==5){
        printf("O dia da semana nessa data eh quinta");
    }
    else if(h==6){
        printf("O dia da semana nessa data eh Sexta");
    }
    return 0;
}
